const animalsArray = [
  {
    pic: 'images/animals/dogs/dog-1.jpg',
    tag: 'Philip',
  },
  {
    pic: 'images/animals/dogs/dog-4.jpg',
    tag: 'Morris',
  },
  {
    pic: 'images/animals/dogs/dog-3.jpg',
    tag: 'Hot the dog',
  },
  {
    pic: 'images/animals/dogs/dog-2.jpg',
    tag: 'Milou',
  },
  {
    pic: 'images/animals/cats/cat-1.jpg',
    tag: 'Mus',
  },
  {
    pic: 'images/animals/cats/cat-2.jpg',
    tag: 'Avo',
  },
  {
    pic: 'images/animals/cats/cat-3.jpg',
    tag: 'Copy',
  },
  {
    pic: 'images/animals/cats/cat-4.jpg',
    tag: 'Pussy',
  },
  {
    pic: 'images/animals/horses/horse-1.jpg',
    tag: 'Power',
  },
  {
    pic: 'images/animals/horses/horse-2.jpg',
    tag: 'Medium',
  },
  {
    pic: 'images/animals/horses/horse-3.jpg',
    tag: 'Rare',
  },
  {
    pic: 'images/animals/horses/horse-4.jpg',
    tag: 'Cream',
  },
  {
    pic: 'images/animals/rabbits/rabbit-1.jpg',
    tag: 'White',
  },
  {
    pic: 'images/animals/rabbits/rabbit-2.jpg',
    tag: 'Roger',
  },
  {
    pic: 'images/animals/rabbits/rabbit-3.jpg',
    tag: 'Bugz Bunny',
  },
  {
    pic: 'images/animals/rabbits/rabbit-4.jpg',
    tag: 'Energiser',
  },
];
